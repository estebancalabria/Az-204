﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hola Mundo Docker");
Console.WriteLine("Si ves este mensaje es porque el contenedor se ha iniciado correctamente.");
